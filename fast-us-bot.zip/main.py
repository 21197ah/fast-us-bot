import os
import requests
from telegram import Bot

# إعدادات أساسية
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")
POLYGON_API_KEY = os.getenv("POLYGON_API_KEY")

bot = Bot(token=TELEGRAM_TOKEN)

# رموز الأسهم اللي نتابعها
STOCKS = ["AAPL", "NVDA", "TSLA", "AMD", "RIOT", "MARA", "GME", "TQQQ", "CVNA"]

def get_stock_data(symbol):
    url = f"https://api.polygon.io/v2/snapshot/locale/us/markets/stocks/tickers/{symbol}?apiKey={POLYGON_API_KEY}"
    r = requests.get(url)
    return r.json()

def check_stocks():
    for symbol in STOCKS:
        data = get_stock_data(symbol)
        try:
            price = data['ticker']['lastTrade']['p']
            change = data['ticker']['todaysChangePerc']
            if change > 5:
                msg = f"🚀 {symbol} ارتفع {change:.2f}% 🔥\nالسعر الحالي: ${price}"
                bot.send_message(chat_id=CHAT_ID, text=msg)
        except:
            continue

if __name__ == "__main__":
    check_stocks()
